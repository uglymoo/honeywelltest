import ReactDom from 'react-dom';
import React from 'react';
import App from './App';
import '../node_modules/bootstrap/dist/css/bootstrap.css';

ReactDom.render(
    <App />,
    document.getElementById('react')
)